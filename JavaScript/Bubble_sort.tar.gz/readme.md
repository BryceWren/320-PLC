# Assignment 1 - JavaScript - Reference Solution

The program takes the name of a comma-delimited text file (CSV) as input on the command line, sorts the file by the first field and prints the file.

## Setup

The JavaScript program will be run using `node.js` which is available from https://nodejs.org/en/

hw1.js and theFile.txt should be located in the same directory when running the command through your terminal

## Running

From the command line:
```
node hw1.js
```

## Notes:

1. This is sorted based on the emoji unicode
2. A sample file is included in the tar
