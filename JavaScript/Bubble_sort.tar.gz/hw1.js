const fs = require('fs');

var splitLine = fs.readFileSync('theFile').toString().split('\n');
for (var i = 0; i < splitLine.length; ++i){

	
	for (var j = 0; j < (splitLine.length - i - 1); ++j){
	
	
		if (splitLine[j].localeCompare(splitLine[j + 1]) > 0){
			
			var temp = splitLine[j];
			splitLine[j] = splitLine[j + 1];
			splitLine[j + 1] = temp;		
		}
	}
		

}

console.log(splitLine)

