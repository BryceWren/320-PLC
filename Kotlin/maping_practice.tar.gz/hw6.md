# Assignment 6 - Kotlin - Reference Solution

This program takes in a file full of names that are then mapped with their keys being the initials and values being their full names.

## Setup

The Kotlin program was written on linux to compile is used

kotlinc -d mymodule.jar -include-runtime hw6.kt




## Running

From the command line:
```
java -jar mymodule.jar

you will then see a prompt for Initials. make sure to use capital letters
```

## Notes:

1. Source code for the AST is a jpg file attatched






| Production | Derivation |
|---|------|
| 1 | commandline => list |
| 2 | list => conditional |
| 3 | conditional => conditional "&&" pipeline |
| 4 | conditional => pipeline "&&" pipeline |
| 4 | pipeline  => command && pipeline |
| 5 | command => word kotlinc d  && pipeline |
| 4 | pipeline => word kotlinc d hello.jar  && command |
| 5 | command => word kotlinc d hello.jar hello.kt && word java jar |
| 6 | redirection => word kotlinc d hello.jar && word java jar hello.jar|
| 6 | redirection => word kotlinc d hello.jar hello.kt && word java jar hello.jar|


| Production | Derivation |
|---|------|
| 1 | commandline => list |
| 2 | list => conditional |
| 3 | conditional => pipeline|
| 4 | pipeline => pipeline "|" command |
| 5 | command => pipeline "|" word grep 2|
| 6 | word => pipeline "|" word grep redirectionop |
| 6 | redirecitonop => pipeline "|" word grep 2> redirection |
| 6 | redirection => pipeline "|" word grep 2> somefile |
| 5 | pipeline ::= command => command "|" word grep 2|
| 5 | word => command something "|"  word grep 2> somefile |
| 5 | word => command word something "|"  word grep 2> somefile |
| 5 | word => command name something "|" word grep 2> somefile |
| 5 | word => find name something "|"  word grep 2> somefile |
