import java.io.File
import java.io.InputStream
import java.util.*

fun main(args: Array<String>) {

  print("Enter File Name: ")
  var stringInput = readLine()
  
  
  val inputStream: InputStream = File(stringInput).inputStream()

  val lineList = mutableListOf<String>()

  val initialsList = mutableListOf<String>()

  
  
  inputStream.bufferedReader().forEachLine {  lineList.add(it)}

	lineList.forEach{ 
		var initials = ""
		for (i in 0 until it.length){
			if (it[i].isUpperCase()){
				initials += it[i].toString()
			}	
	 	}
		initialsList.add(initials.toString())	
	}
	
	
	val zipName = initialsList.zip(lineList)

	
	
	val myMap = zipName.map {it.first to it.second}.toMap()
	
	println(myMap)
	while(true)
	{
	
	print("initials? ")
	var userInput = readLine()
	var count = 0
	for (key in myMap.keys){
	if (userInput.equals(key))
		{
		println(myMap.get(key))
		
		}
		else {
			count++
		}
	
	}
	if (userInput == null){
		break
		}
	else if (count == myMap.size){
		println("Not Found: Make sure to use capital letters")
	}

	}
}

