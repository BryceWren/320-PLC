
fun main (args: Array<String>) {
	var numWord = args.size
	val charList = args.map { it.count() }
	val sum = charList.sum()
	val mean = (sum / numWord).toDouble()
	val stanDev = args.map { Math.pow(it.count() - mean.toDouble(), 2.0) }
	val finDev = Math.sqrt(stanDev.sum() / numWord)
	println("the Mean is $mean")
	println("the Standard Deviation is: $finDev")
}