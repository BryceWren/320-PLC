# Assignment 7 - Kotlin - Reference Solution

This program takes user input with spaces seperating words then takes the average/mean of letters per word then finds the standard deviation of the word length

## Setup

The Kotlin program was written on linux to compile is used

kotlinc -d hw7.jar -include-runtime hw7.kt


## Running

From the command line:
```
java -jar hw7.jar <type letters here with spaces seperating them>


```

## Notes:

1. Source code for the AST and GSD have jpg file attatched

![Graph 2a](GSD.pdf)
![Graph 2c](AST_2.pdf)


## Derivation:

| Production | Derivation |
|---|------|
| a | fun -> "fun" <SomeFunNow> <block>
| b | block -> "fun" <SomeFunNow> <{stmt{stmt}}>
| c | stmt -> {<assignment_stmt>{<stmt>}}
| d | assign_stmt => {idx "=" 5{<stmt>}}
| c | stmt => {idx "=" 5{<while_stmt>}}
| f | stmt => {idx "=" 5{"while" "(" <idx> <relop> <0> ")" <block>}}
| h | relop => {idx "=" 5{"while" "(" <idx> <"=="> <0> ")" <block>}}
| b | block => {idx "=" 5{"while" "(" <idx> <"=="> <0> ")" {<stmt>{<stmt>}}
| c | stmt => {idx "=" 5{"while" "(" <idx> <"=="> <0> ")" {<fn_call>{<assignment_stmt>}}
| g | stmt => {idx "=" 5{"while" "(" <idx> <"=="> <0> ")" {<print (idx)>{<assignment_stmt>}}
| d | stmt => {idx "=" 5{"while" "(" <idx> <"=="> <0> ")" {<print (idx)>{<idx "=" [idx "-"] 1>}}

| b | block => {stmt { stmt } }
| c | stmt => {assignment_stmt { if_stmt}}
| d | assign_stmt => {frodo " = " "kotlin rules" { if_stmt}}
| e | if_stmt => {frodo " = " "kotlin rules" { 
	"if" "(" <frodo <relop> "rules" ")" <block> 
		"else <block> }}}
| h | relop => {frodo " = " "kotlin rules" { 
	"if" "(" <frodo <==> "rules" ")" <block> 
		"else <block> }}}
| b | block => {frodo " = " "kotlin rules" { 
	"if" "(" <frodo <==> "rules" ")" <{stmt{stmt}}> 
		"else <{stmt{stmt}}> }}}
| c | stmt => {frodo " = " "kotlin rules" { 
	"if" "(" <frodo <==> "rules" ")" <{fn_call{const}}> 
		"else <{fn_call{const}}> }}}
| g | fn_call => {frodo " = " "kotlin rules" { 
	"if" "(" <frodo <==> "rules" ")" <{Print "(""Yes"")"}> 
		"else <{Print "(""No"")"}> }}}















		
		
