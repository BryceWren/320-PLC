

const fs = require("fs");


var input = process.argv
var splitLine = fs.readFileSync(input[2]).toString().split('\n')
var splitComma = splitLine.toString().split(',')


for (var i = 0; i < splitLine.length - 1; ++i){
	var farray = splitLine[i].toString().split(',')
	splitLine[i] = farray
	
}
splitLine = splitLine.filter((str) => str !== '')


var columns = 4
var rows = (splitLine.length - 1) 
var arrayVal = new Array(splitLine.length - 1);


var index = input[3]


function merge(arr, l: number, m: number, r: number, user: number)
{
    var n1 = m - l + 1;
    var n2 = r - m;
 
    
    var L = new Array(n1);
    var R = new Array(n2);
 
 
    for (var i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (var j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];
 
    
    var i = 0;
    var j = 0;
    var k = l;
 
    while (i < n1 && j < n2) {	
	
        if (L[i][user].localeCompare(R[j][user]) < 1) {
            arr[k] = L[i];
            i++;
        }
        else {
            arr[k] = R[j];
            j++;
        }
        k++;
    	
	}

    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
 

    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}
 

function mergeSort(arr,l: number, r: number, user: number){
    if(l >= r){
        return;
    }
    var m = l + Math.floor((r-l)/ 2);
    mergeSort(arr,l,m, user);
    mergeSort(arr,m + 1,r, user);
    merge(arr,l,m,r, user);
}

mergeSort(splitLine, 0, splitLine.length - 1, parseInt(index))
console.log(splitLine)

	


	
