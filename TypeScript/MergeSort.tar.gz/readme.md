# Assignment 2 - TypeScript - Reference Solution

The program takes the name of a comma-delimited text file (CSV) as input on the command line, sorts the file by whichever column the user inputs. using array indeces [0,1,2...]

## Setup

The TypeScript program will be run using `node.js` which is available from https://nodejs.org/en/

hw2.js file is located in the Assignment 2 folder



## Running

From the command line:
```
node hw2.js <file-name> <column in which you want to sort by>
```

## Notes:

1. Source code for the AST is within the .DOT file
2. as well as a png showing the tree
