package main

import(
	"fmt"
	"os"
	"io/ioutil"
	"log"
	"strings"
	"time"
	"net/http"
	"regexp"
)

func getURL() []string{
	//gets argument from command line
	fileName := os.Args[1]
	
	fileContent, err := ioutil.ReadFile(fileName)
	if err != nil {
		log.Fatal(err)	
	}
	
	sliceData := strings.Split(string(fileContent), "\n")
	
	return sliceData
	
}
func goroutine(url string){
	
	resp, err := http.Get(url)
	if err != nil{
		fmt.Printf("URL does not work")
	}
	fmt.Printf("length of HTML %s is... \n", url)
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil{
		panic(err)	
	}
	
	l := len(body)
	fmt.Println("length: ", l)
	bd := string(body)
	

	re := regexp.MustCompile("<title>([A-z]*)")
	subStr := re.FindStringSubmatch(bd)
	if subStr != nil{
			fmt.Println("title of URL is: %s", subStr)
	}
	if subStr == nil{
		fmt.Println("NO TITLE!")	
	}
	
	

	
}
func main() {
	sliceData := getURL()
	
	for i:= 0; i < len(sliceData); i++ {//looping through each line slice
		fmt.Println(sliceData[i])
		indivSlice := sliceData[i]
		go goroutine(indivSlice)
		time.Sleep(time.Second*2)
		
		
	}
	
	
	
	
	
	
	
}