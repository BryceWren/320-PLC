# Assignment 9 - GO - Reference Solution


The program takes in command line arguments with the first argument being a file of URL's. These URL's are then used to count the length of the html body using go routines as well as to find a title within that html using regular expresions.

## Setup

The Go assignment will use golang make sure to install (on linux)

sudo apt install golang



## Running

From the command line:
```
go run hw9.go <file_name>
```

## Notes:


