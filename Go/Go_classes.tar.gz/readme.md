# Assignment 8 - GO - Reference Solution


The program takes in command line arguments with the first argument being a file that is comma-delimited with three fields. the second argument being the field you want it sorted by.

## Setup

The Go assignment will use golang make sure to install (on linux)

sudo apt install golang



## Running

From the command line:
```
go run hw8.go <file_name> <number on which field to sort>
```

## Notes:

1. This is sorting alphabetically
