package main

import (
	"fmt"
	"os"
	"bufio"
	"log"
	"strings"
	"strconv"
	"sort"
)
type Actor struct{
		fName string
		lName string
		movie string
	}
type Actors struct{

		thatactor []Actor	
	}

type Sort interface{
	
	Sort() []Actor
	
}

func (a Actor)String() string{
	
	return fmt.Sprintf("Last Name: %s, First Name: %s, Series: %s", a.lName, a.fName, a.movie)
}


func (a *Actors)Sort(num int){
	if num == 0{
		sort.SliceStable(a.thatactor, func(i, j int) bool { return a.thatactor[i].lName < a.thatactor[j].lName })
		
	}
	
	if num == 1{
		sort.SliceStable(a.thatactor, func(i, j int) bool { return a.thatactor[i].fName < a.thatactor[j].fName })
		
		
	}
	if num == 2 {
		sort.SliceStable(a.thatactor, func(i, j int) bool { return a.thatactor[i].movie < a.thatactor[j].movie })
			
	}
	
	
}

						 

func main() {
	
	//a := new(Actor)
	temp := new(Actors)
	
	arg := os.Args[1]
	arg2 := os.Args[2]
	
	f, err := os.Open(arg)
	
	if err != nil {
		log.Fatal(err)	
	}
	
	defer f.Close()
	
	scanner := bufio.NewScanner(f)
	//fmt.Println(arg2)
	for scanner.Scan() { //taking each line loop
		

		scannerSlice := strings.Split(scanner.Text(), ",")

		
		a := Actor{lName: scannerSlice[0], fName: scannerSlice[1], movie: scannerSlice[2]}
		temp.thatactor = append(temp.thatactor, a)
		
		
		}//end of for loop
x, thetype := strconv.Atoi(arg2)
	temp.Sort(x)
	fmt.Println(thetype)
	for _, w := range temp.thatactor{
		fmt.Printf("%s\n", w)
	}
	/*
	for _, w := range *words {
		fmt.Printf("%s\n", w)
		// fmt.Printf("%s is of length %d\n", w.word, w.len)
	}
	*/
	
	}
	
	