theqsort :: (Ord alist) => [alist] -> [alist]
theqsort [] = []
theqsort (laverne:shirley) =
  let smallSort = theqsort [alist | alist <- shirley, alist <= laverne]
      biggerSort = theqsort [alist | alist <- shirley, alist > laverne]
  in  smallSort ++ [laverne] ++ biggerSort