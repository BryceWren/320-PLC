# Assignment 3 - Haskell - Reference Solution

The program takes in a list from the user and sorts it from least to greatest using the quick sort algorithm.

## Setup

The Haskell program will be run using a ghc compiler which is available from https://www.haskell.org/ghc

hw3.hs file is located in the hw3 folder



## Running

From the command line:
```
to compile use :l hw3.hs
to run type: theqsort [number perameters using comma seperation]
```

## Notes:

1. the Javascript framework is included with the hw3.hs file
