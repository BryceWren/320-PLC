
module Functions
    where
import Distribution.Simple.Utils (xargs)
piece' x
	|x < -1 = (2*(x)+1)
	|(-1 <= x && x <= 3) = -2
	|x > 3 = (-3*x+7)

exp' x 0 = 1
exp' x y = x * exp' x (y-1)
	
comp1 :: [Int] -> [Int]
comp1 [] = []
comp1  fx = map (^2) fx
comp2 = foldr (+) 0

comp' x = (comp2.comp1) x


count fn [] = []
count fn (x:xs)
	| fn x = x : count fn xs
	|otherwise = count fn xs


count'filter fn l = filter (fn) l
--do not need to clarify types when defining the variable for the list

count'lc fn xs = [x | x <- xs, fn x]


closure = count'filter(\x -> x > 10)






	
	
	
	
	