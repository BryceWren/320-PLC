# Assignment 4 - Haskell - Reference Solution

this program does an assortment of functions dealing with Recursion, Functional Composition, List Comprehension, and Currying

## Setup

The Haskell program will be run using a ghc compiler which is available from https://www.haskell.org/ghc

hw4.hs file is located in the hw4 folder



## Running

From the command line:
```
to compile use :l hw4.hs
1a) in order to run type piece' <arg>
	- if you use negative values put () around them i.e. (-2)
1b)in order to run type exp' <x><y>
2) type comp' [<list>]
3a - c) you will need to declare a function called isneg x = x < 0
	- type:
		-count isneg [<list>]
		-count'filter isneg [<list>]
		-count'lc isneg [<list>]
4) type closure [<list>]
```

## Notes:

1. 
