// -----------------------------------
// CSCI 340 - Operating Systems
// Spring 2023
// server.c source file
// Assignment 2
//
// -----------------------------------

#include <string.h>
#include <stdio.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include "server.h"
#include <stdlib.h>

// ------------------------------------
// Function prototype that creates a socket and 
// then binds it to the specified port_number 
// for incoming client connections
// 
// Arguments:	port_number = port number server socket will be bound to.
//
// Return:      Socket file descriptor (or -1 on failure)
//
int bind_port(unsigned int port_number)
{
  // -------------------------------------
  // NOTHING TODO HERE :)
  // -------------------------------------
  // DO NOT MODIFY !

  int socket_fd;
  int set_option = 1;

  struct sockaddr_in server_address;
  socket_fd = socket(AF_INET, SOCK_STREAM, 0);
  setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, (char*)&set_option,
	     sizeof(set_option));

  if (socket_fd < 0) return FAIL;

  bzero((char *) &server_address, sizeof(server_address));

  server_address.sin_family = AF_INET;
  server_address.sin_addr.s_addr = INADDR_ANY;
  server_address.sin_port = htons(port_number);

  if (bind(socket_fd, (struct sockaddr *) &server_address,
	     sizeof(server_address)) == 0) {
    return socket_fd;
  } else {
    return FAIL;
  }
} // end bind_port function

// ------------------------------------
// Function prototype that accepts a client
// socket connection
// 
// Arguments:	server file descriptor
//
// Return:      Termination status of client (0 = No Errors, -1 = Error)
//
int accept_client(int server_socket_fd)
{
  int exit_status = OK;
  int client_socket_fd = -1;
  socklen_t client_length; 
  struct sockaddr_in client_address;
  char request[2048];

  client_length = sizeof(client_address);

  client_socket_fd = accept(server_socket_fd,
			     (struct sockaddr *) &client_address,
			     &client_length);
  // -------------------------------------
  // TODO:
  // -------------------------------------
  // Modify code to fork a child process
  // -------------------------------------
	int pId = fork();
	if(pId == 0){
		
		char blank_body[400];
		//copy beginning of orginal body to new blank body
		strcpy(blank_body,"<html><body><h2>CSCI 340 (Operating Systems) Homework 2</h2><table border=1 width=\"50%\"><tr><th>Key</th><th>Value</th></tr>");
		if (client_socket_fd >= 0) {
    		bzero(request, 2048);
    		read(client_socket_fd, request, 2047);
    		if (DEBUG) printf("Here is the http message:\n%s\n\n", request);
    		
    		//find if get or post
			char getOrPost[2];
			strncpy(getOrPost, request, 1); //copy it so i don't mess with orginal string
			getOrPost[1] = '\0'; //this is so i only need to check the first character if its a G its get but anything else is post

			if(strcmp(getOrPost, "G") == 0){
				char * findQuestionMark = "?";
				char * findSpace = " ";
				char * ptr = strchr(request, *findQuestionMark);
				char * pairs;
				char* temp1;
				
				
				pairs = strtok_r(ptr, findSpace, &temp1); //
				
				//create string holder for isolated url
				int testLength = strlen(&pairs[0]);
				char test[testLength+1];
				strncpy(test, &pairs[0], testLength+1);

				char * checkAnd = "&";
				char * temp2;
				char * temp3;
				char * equalCheck = "=";
				ssize_t countAnds = 1;
				
				
				for (int i = 0; i < testLength;i++){
					if( test[i] == *checkAnd) {
						countAnds++;
					}
				}
				countAnds = countAnds * 2;
				
				
				char * keyAndVals = strtok_r(test, checkAnd, &temp2);//split by &
				char * holder[countAnds][100]; //place to hold the split by ands
				int holderIndex = 0;
				
				
				while(keyAndVals != NULL){	
					//split by '='
					char * keyOrVals = strtok_r(keyAndVals, equalCheck, &temp3);
					while(keyOrVals != NULL){
						if(holderIndex == 0){
							
							holder[holderIndex][0] = &keyOrVals[1]; //first key has ? so we move the indivkeys or val + 1 to pass it
						}
						else{
							
							holder[holderIndex][0] = keyOrVals; //store key inside holder of 2d arrays
						}
						
						keyOrVals = strtok_r(NULL, "=", &temp3);
						holderIndex++; //increment inorder to go to next holder "spot"
					}//end of second while		
					keyAndVals = strtok_r(NULL, checkAnd, &temp2);
				}//end of firsst while
				
				//iterate through key and value array
				for(int i = 0; i < holderIndex; i++){
					if(i % 2 == 0){
						
						strcat(blank_body, "<tr><td>");
						strcat(blank_body, *holder[i]);
						strcat(blank_body, "</td>");
						
					} else if (i % 2 == 1){

						strcat(blank_body, "<td>");
						strcat(blank_body, *holder[i]);
						strcat(blank_body, "</td></tr>");	
						
					}
				}//end of for loop
				
				strcat(blank_body,"</table></body></html>");
				
	 }
	 else {
	 	//was out of town the weekend of completion and was only able to complete GET.
		 //but this is where POST would be
	 }	
    //THIS IS AN EXAMPLE ENTITY BODY
    //char* entity_body2 = "<html><body><h2>CSCI 340 (Operating Systems) Homework 2</h2><table border=1 width=\"50%\"><tr><th>Key</th><th>Value</th></tr></table></body></html>";
	
    char response[512];
    sprintf(response, "HTTP/1.1 200 OK\r\nContent-Length: %d\r\n\r\n%s",
	     (int)strlen(blank_body), blank_body);
		
    if (DEBUG) printf("%s\n", response);
		
    write(client_socket_fd, response, strlen(response));

  }
 	exit(0);
  }//closing bracket for if child statement, everything before this is in the child
  else {
    exit_status = FAIL;
  }
	
	close(client_socket_fd);


  if (DEBUG) printf("Exit status = %d\n", exit_status);
	printf("end of accept client function\n");

  return exit_status;
} // end accept_client function
