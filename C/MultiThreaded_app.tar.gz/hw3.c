
#include <stdio.h>	// IO functions
#include <stdlib.h> 	// std lib function
#include <unistd.h>	// close function
#include <pthread.h>	// creating, running, joining threads
#include <string.h>	// string processing 
#include "web.h"	// our code :)

#define DEBUG 1 



// -----------------------------------
// CSCI 340 - Operating Systems
// Fall 2022
// hw3.c file
// 
// Homework 3
//
// -----------------------------------

// ---------------------------------------------
// Global variable shared by all threads
// This is not thread safe.
web_t* web_array;


// ---------------------------------------------
// Function prototypes to read and write url files
int read_url_file( char* file_path, web_t* web_array );
int write_url_file( char* file_path, web_t* web_array, int num_urls );

// ---------------------------------------------
// Function prototypes that is ran by a thread
void th_run( int* i );

int main( int argc, char *argv[] ) {

	int i = 0;
	int write_error = 0;

	// malloc web_t array with 100 elements
	web_array = malloc( sizeof( web_t )*100 );

	// -------------------------------------------------
	// Verify the correct number of arguments are provided
	// when the application is executed.

	if ( argc == 2 ) { 

		int num_urls = read_url_file( argv[1], web_array );

		if ( DEBUG ) printf("Number of urls in text file = %d\n", num_urls);

		// -----------------------------------------
		// TODO:
		// ------------------------------------------
		// You complete steps 1 to 3 below.
		//
		// If either the thread create or join fails, you may exit the entire
		// program.
		// 
		// Hint: you will loop through an array of threads

		pthread_t thread_array[num_urls];
		int index[num_urls];

		for ( i=0; i<num_urls; i++ ) {

			if ( DEBUG ) {
				//printf("URL=%s\n", web_array[i].url ); //URL NAMES
				//printf("CNT=%d\n", web_array[i].link_cnt ); //CNT?
				//printf("WEBPAGE=%s\n", web_array[i].webpage ); //HTTP OF WEBPAGE
			}
	
			
			// -------------------------------------------------------------
			// STEP 1: Create and run threads
			// Hint: Each thread will execute the th_run function
			// 	 The array index value is a shared variable
			//
			// If one thread cannot be created (i.e. an error occurs) you may exit
			// the entire program.
			index[i] = i;
		     if(pthread_create(&thread_array[i], NULL, (void*) th_run,(void*) &(index[i])) != 0){
				 exit(write_error);
				 //exit if error creating threads
			 }
			else{
				// it may say one less created due to it creating a thread within the if statement
				//printf("thread created %d \n", i);
				
				}
			
			 
			
		}//end of for loop
		
		
		// -------------------------------------------------------------
		// STEP 2: Join all threads
		//
		// If one thread cannot be joined (i.e. an error occurs) you may exit
		// the entire program.
		for (int j = 0; j < num_urls; j++){
			if (pthread_join(thread_array[j], NULL) != 0){
			exit(write_error);	
			}
			else{
				//printf("thread joined %d \n", j);
			}
		}//end of for loop
		

		// -------------------------------------------------------------
		// STEP 3: write results to output file 
		// Note: please do not change this file name (used for testing purposes)
		// output file name = "make_merica_great_again.txt"
		char * fileName = "make_merica_great_again.txt";
		write_url_file(fileName, web_array, num_urls);
		
		

	} else {

		printf( "URL file is not specified!\n" );
		printf( "Example usage: %s %s\n", argv[0], "url.txt" );

	}

	return OK;
     
} // end main function



// ------------------------------------
// Function ran by an individual thread
// 
//
// Arguments:	i = an index value (to access individual web_t structs in the web_array)
//
// Return:     	nothing (void)
//
void th_run( int* i ) {

	// -------------------------------------
	// Please do not modify this code
	// -------------------------------------

	if ( web_array[ (*i) ].link_cnt == OK ) {

		parse( &web_array[ (*i) ] );

	} else printf( "[%s] failed to retrieve webpage\n", web_array[ (*i) ].url );

	pthread_exit( NULL );

} // end th_run function

// ------------------------------------
// Function that writes the identified links 
// stored in the web_t links field to formated
// text file.
// 
// 
//
// Arguments:	file_path = fully qualified path to output text file
//		web_array = pointer to array of web_t structs
//		num_urls = the total number of websites in the url.txt file
//
// Return:     	OK on success, FAIL on error
//
int write_url_file( char* file_path, web_t* web_array, int num_urls ) {
/*
	char* url; 	// string that has the url 
	char* webpage; // string that has the html web page
	int link_cnt;	// integer that represents the total number of href link counts
	char** links; 	// array that stores a string for each href that contains the word "trump"
	*/
	FILE* outfile;
	outfile = fopen(file_path, "w+");
	
	char* url;
	char* website;
	
	for (int i = 0; i < num_urls; ++i){
		int linkCounter = web_array[i].link_cnt;
		//printf("%d \n", linkCounter);		//CNT is staying at 0 so it is not going to the second for loop 
		
		for (int j = 0; j < linkCounter; ++j){
			website = web_array[i].url;
			
			url = web_array[i].links[j];
			if(strstr(url, "trump") != 0){
				ssize_t lineMem = strlen(url) + strlen(website) + 10;
				char line[lineMem];
				
				website = website + 4; //skip www.
				
				strcpy(line, website);
				strcat(line, ", ");
				strcat(line, url);
				strcat(line, "\n");
				
				fputs(line, outfile);
			}//end of if statement
		}//end of linkCounter
	}//end of num_urls
	

	fclose(outfile);
	
	
	// -----------------------------------------
	// TODO:
	// -----------------------------------------
	// The format of this file is provided below. 
	// 
	// <url>, <link>\n
	//
	//
	// For example,
	//
	//	usatoday.com, /story/news/politics/2018/10/23/donald-trump-looks-ahead-life-after-midterms/1732675002/
	//	wsj.com, /articles/trump-not-satisfied-with-saudi-arabias-explanation-for-khashoggi-death-1540237930?mod=hp_major_pos8
	//      .
	//	.
	//      .
	//

	

	return OK;

} // end write_url_file function



// ------------------------------------
// Function that reads the url in the input
// url text file.
// 
// 
// Arguments:	file_path = fully qualified path to output text file
//		web_array = pointer to array of web_t structs
//
// Return:     	Total number of urls defined in the url text file
//
int read_url_file( char* file_path, web_t* web_array ) {

	// -------------------------------------
	// Please do not modify this code
	// -------------------------------------

	int url_cnt = 0;

	FILE* fhnd;

    	fhnd = fopen( file_path, "r" );

    	char line[50];

    	if ( fhnd != NULL ) {

        	while ( fgets( line, sizeof( line ), fhnd ) != NULL ) {

			line[strlen(line)-1] = '\0';
			web_array[url_cnt].url = malloc(sizeof(char)*100);
			sprintf( web_array[url_cnt].url, "www.%s", line );

			web_array[url_cnt].link_cnt = OK;

			if ( FAIL == get_webpage( &web_array[url_cnt++] ) ) {

				printf("Failed to load webpage for URL( %s )\n", web_array[url_cnt--].url );
				web_array[url_cnt].link_cnt = FAIL;				

			}

        	}

    	} else url_cnt = FAIL;

    	fclose( fhnd );

	return url_cnt;

} // end read_url_file function

