// -----------------------------------
// CSCI 340 - Operating Systems I 
// Spring 2023 (Anthony Leclerc)
// utils.c implementation file
// Homework Assignment 1
//
// -----------------------------------

// these are the ONLY library header files that can be used. Under no
// circumstances can additional library header files be included.  In
// particular, this restriction means you CANNOT USE any function
// declared in <string.h>, which includes functions such as: strtok(),
// strchr(), strstr(), strlen(), index(), and others.

// NOTE: when you compile, DO NOT IGNORE WARNINGS!  These warnings are
// likely indicating you are doing something wrong, such as using a
// library function that you are not allowed to use or passing the
// wrong type of argument into a function.

#include <stdio.h>	// standard I/O functions
#include <stdlib.h> 	// atof()
#include <math.h>	// math functions

#include "utils.h"	// user defined functions

// see utils.h for the required function prototypes and specifications

// NOTE: you may add any "helper" functions you need to get the job done.
//       for example, if you need to determine the length of a string.

// put your IMPLEMENTATION of the function prototypes below:

int read_lines(char* filename, line_t* line_arr, int n){
	
	FILE* fp;
	fp = fopen(filename, "r");
	char data_arr[80];
	int count = 0;
	double dblconvert;
	
	
	
	
	while(fgets(data_arr, 80, fp) != NULL || count == n || data_arr[0] == '\0'){
		int t = 0;
		char temp[80];
		int xchecked = 0;
		int flipped = 0;
		line_t line1;
		point_t point1;
		point_t point2;
		int newpoint = 0;
		
		
		
		for (int i = 0; i < 80; i++){
			if (data_arr[i] != ',' && data_arr[i] != '\n'){
				
				temp[t] = data_arr[i];
				t += 1;
			}
			else{
				temp[t] = '\0';
				dblconvert = atof(temp);
				if( newpoint != 1)
				{
					if (xchecked != 1)
					{
						double x1 = dblconvert;
						xchecked = 1;
						flipped += 1;
						point1.x = x1;
						
					}
					else if(xchecked == 1)
					{
						double y1 = dblconvert;
						flipped += 1;	
						point1.y = y1;
						xchecked = 0;
						newpoint = 1;	
					}
					
				}
				else
				{
				if (xchecked != 1)
				{
					double x2 = dblconvert;
					xchecked = 1;
					flipped += 1;
					point2.x = x2;
					
				}
				else if(xchecked == 1)
				{
					double y2 = dblconvert;
					flipped += 1;
					point2.y = y2;
					xchecked = 0;
					newpoint = 0;
					
				}
				
				}
				
				t = 0;
			
				
				if (flipped % 4 == 0){
					line1.p0 = point1;
					line1.p1 = point2; 
					line_arr[count] = line1;
					
					
				}
			
				
			}//end of else
			
		
		}//end of for loop
		
		count += 1;	

		
		
							 
	}//end of while
	

	fclose(fp);
	return count;
}
double calc_direction(line_t* line_ptr){
	double x1 = line_ptr->p0.x;
	double y1 = line_ptr->p0.y;
	double x2 = line_ptr->p1.x;
	double y2 = line_ptr->p1.y;
	double dir = atan2(y2-y1,x2-x1);
	return dir;
}
double calc_magnitude(line_t* line_ptr){
	double x1 = line_ptr->p0.x;
	double y1 = line_ptr->p0.y;
	double x2 = line_ptr->p1.x;
	double y2 = line_ptr->p1.y;
	double mag = sqrt(pow((x2 - x1),2) + pow((y2-y1), 2.0));

	return mag;
	
}
